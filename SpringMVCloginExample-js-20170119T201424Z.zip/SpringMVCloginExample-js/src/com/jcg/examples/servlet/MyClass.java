package com.jcg.examples.servlet;

public class MyClass {

    public int method1() {    
        //somecode
    	return 1;
    }

    public int method2() {
        //some code
    	return 2;
    }

    public int method3() {
        //some code
    	return 3;
    }
}
