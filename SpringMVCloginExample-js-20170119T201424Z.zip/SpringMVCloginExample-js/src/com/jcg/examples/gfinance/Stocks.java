package com.jcg.examples.gfinance;

public class Stocks {
	
	float diffper;
	float diff;
	String CName;
	float l_fixN;
	float l_fixB;
	//int check;
	public float getDiffper() {
		return diffper;
	}
	public void setDiffper(float diffper) {
		this.diffper = diffper;
	}
	public float getDiff() {
		return diff;
	}
	public void setDiff(float diff) {
		this.diff = diff;
	}
	public String getCName() {
		return CName;
	}
	public void setCName(String cName) {
		CName = cName;
	}
	public float getL_fixN() {
		return l_fixN;
	}
	public void setL_fixN(float l_fixN) {
		this.l_fixN = l_fixN;
	}
	public float getL_fixB() {
		return l_fixB;
	}
	public void setL_fixB(float l_fixB) {
		this.l_fixB = l_fixB;
	}
//	public int getCheck() {
//		return check;
//	}
//	public void setCheck(int check) {
//		this.check = check;
//	}
//	
	

}
